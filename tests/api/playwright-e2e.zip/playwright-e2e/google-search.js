const { chromium } = require('playwright');

(async () => {
  // Launch the browser
  const browser = await chromium.launch({ 
    headless: false,
    slowMo: 100 // Slow down actions to appear more human-like
  });
  
  // Create a new context with a more realistic user agent
  const context = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    viewport: { width: 1280, height: 800 }
  });
  
  // Create a new page
  const page = await context.newPage();
  
  try {
    // Navigate to Google
    await page.goto('https://www.google.com');
    
    // Wait for the search input
    await page.waitForSelector('textarea[name="q"]');
    
    // Type "playwright" into the search box with human-like typing
    await page.type('textarea[name="q"]', 'playwright', { delay: 100 });
    
    // Small pause before pressing Enter
    await page.waitForTimeout(500);
    
    // Press Enter to search
    await page.press('textarea[name="q"]', 'Enter');
    
    console.log('If you see a verification check, please complete it manually.');
    console.log('The browser will stay open for 2 minutes to allow time for verification.');
    console.log('After completing verification, the search results should appear automatically.');
    
    // Wait longer for either search results or verification
    try {
      await page.waitForSelector('#search', { timeout: 120000 }); // 2 minute timeout
    } catch (error) {
      console.log('Timeout waiting for search results. You may need more time for verification.');
    }
    
    // Keep browser open for manual interaction
    await new Promise(resolve => setTimeout(resolve, 120000)); // Keep open for 2 minutes
    
  } catch (error) {
    console.error('An error occurred:', error);
  }
  // Note: We're not automatically closing the browser anymore
})(); 
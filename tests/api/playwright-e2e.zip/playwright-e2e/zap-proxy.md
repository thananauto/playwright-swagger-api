docker run -u zap -p 8080:8080 -v $(pwd):/zap/wrk/:rw -d --name zap-proxy \
zaproxy/zap-stable zap.sh -daemon -host 0.0.0.0 -port 8080 \
-config api.addrs.addr.name='.*' -config api.addrs.addr.regex=true 

docker run -u zap -p 8080:8080 -v $(pwd):/zap/wrk/:rw -d --name zap-proxy \
zaproxy/zap-stable zap.sh -daemon -host 0.0.0.0 -port 8080 \
-config api.addrs.addr.name='.*' -config api.addrs.addr.regex=true -config api.key=secret


docker run  -v $(pwd):/zap/wrk/:rw --network='host' zaproxy/zap-stable zap-baseline.py -t https://www.saucedemo.com -r scan-report.html

import { chromium, expect } from 'playwright';

(async () => {
//connect the existing browser using Websocket debugger address
//const browser = await chromium.connectOverCDP('ws://0.0.0.0:9222/devtools/browser/c875ac60-419f-4a77-9e4f-163f53c8fed9', { timeout: 60000});
const browser = await chromium.connectOverCDP('ws://localhost:9223/devtools/browser/5502fdea-927c-4b8a-a756-ef4acafe3823');
///const browser = await chromium.connect({ wsEndpoint: 'ws://localhost:9222/devtools/browser/c875ac60-419f-4a77-9e4f-163f53c8fed9'});
const defaultContext =   browser.contexts()[0] //get the first opened tab

const page = defaultContext.pages()[0]
/**
 * type and test the code snippet after this line
 */
await page.goto('https://www.amazon.com')
await expect(page).toHaveURL(/amazon/)


/**
 * don't close the browser or page instance
 */
return await page.title()
})()

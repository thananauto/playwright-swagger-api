const { chromium } = require('playwright');
const axios = require('axios');
const fs = require('fs');
const ZAP_PROXY = "http://127.0.0.1:8080";
const BASE_URL = "https://www.saucedemo.com/v1/";
const LOGIN_URL = "https://www.saucedemo.com/v1/";
const USERNAME = "standard_user";
const PASSWORD = "secret_sauce";

(async () => {
  // Launch Chrome with ZAP Proxy and ignore HTTPS errors
  const browser = await chromium.launch({
    headless: false,
    args: [`--proxy-server=${ZAP_PROXY}`]
  });

  const context = await browser.newContext({
    ignoreHTTPSErrors: true // Ignore HTTPS errors
  });

  const page = await context.newPage();
  await page.goto(LOGIN_URL);

  // Perform Login
  await page.getByPlaceholder('username').fill(USERNAME);
  await page.getByPlaceholder('password').fill(PASSWORD);
  await page.getByRole('button', { name: 'Login' }).click();
  await page.waitForTimeout(2000); // Wait for login to complete
  console.log("✅ Authentication successful");

  // Enumerate All Links in ERP System
  const links = await page.$$eval('a', anchors => anchors.map(a => a.href));
  console.log(`🔗 Found ${links.length} links`);

  // Start Spider Scan
  console.log("🕷️ Starting Spider Scan…");
  const spiderScan = await axios.get(`${ZAP_PROXY}/JSON/spider/action/scan/?apikey=secret`, {
    params: { url:  page.url(), recurse: true }
  });
  console.log(await spiderScan.data)
  //await new Promise(resolve => setTimeout(resolve, 20000)); // Wait for Spider Scan to finish

  // Start Active Scan
  console.log("⚡ Starting Active Scan…");
  const activeScan = await axios.get(`${ZAP_PROXY}/JSON/ascan/action/scan/?apikey=secret`, { params: { url:  page.url() } });
  console.log(await activeScan.data)
  //await new Promise(resolve => setTimeout(resolve, 60000)); // Wait for Active Scan to finish

  // Generate Report
  console.log("📄 Generating Report…");
  const report = await axios.get(`${ZAP_PROXY}/OTHER/core/other/htmlreport/?apikey=secret`);
  fs.writeFileSync('erp_vulnerability_report.html', report.data);
  console.log("✅ Vulnerability Scan Completed. Report Saved as 'erp_vulnerability_report.html'.");

  await browser.close();
})(); 





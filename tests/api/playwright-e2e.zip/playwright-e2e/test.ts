import * as fs from 'fs/promises';
import * as yaml from 'js-yaml';

// Function to read and parse the YAML file
async function readYamlFile(filePath: string): Promise<any> {
  try {
    // Read the YAML file as a string
    const fileContents = await fs.readFile(filePath, 'utf8');

    // Parse the YAML string into a JavaScript object
    const data = yaml.load(fileContents) as any;

    return data;
  } catch (err) {
    console.error('Error reading or parsing YAML file:', err);
    throw err;
  }
}

// Function to process and output each section separately
async function processYamlData(filePath: string) {
  try {
    const yamlData = await readYamlFile(filePath);

    // Access the 'application' array
    const applications: any = yamlData.application;
    console.log('Applications:', applications[0].applicationId);

    // Access the 'apps' array
    const apps: any = yamlData.apps;
    console.log('Apps:', apps[1].applicationId);

    // You can manipulate or process applications and apps separately as needed
    applications.forEach((app: { name: string }) => {
      //console.log(`Application Name: ${app.name}`);
    });

    apps.forEach((app: { name: string }) => {
      //console.log(`App Name: ${app.name}`);
    });

  } catch (err) {
    console.error('Failed to read or process YAML file.', err);
  }
}

// Usage example
const filePath = 'test.yaml'; // Path to your YAML file
processYamlData(filePath);
document.addEventListener('DOMContentLoaded', function() {
    const actionButton = document.getElementById('actionButton');
    const toggleButton = document.getElementById('toggleButton');
    const status = document.getElementById('status');

    // Handle action button click
    actionButton.addEventListener('click', function() {
        chrome.runtime.sendMessage({ action: 'performAction' }, function(response) {
            status.textContent = 'Action performed: ' + response.result;
        });
    });

    // Handle toggle button click
    toggleButton.addEventListener('click', function() {
        chrome.storage.local.get(['featureEnabled'], function(result) {
            const newState = !result.featureEnabled;
            chrome.storage.local.set({ featureEnabled: newState }, function() {
                toggleButton.textContent = newState ? 'Disable Feature' : 'Enable Feature';
                status.textContent = 'Feature ' + (newState ? 'enabled' : 'disabled');
            });
        });
    });

    // Initialize toggle button state
    chrome.storage.local.get(['featureEnabled'], function(result) {
        toggleButton.textContent = result.featureEnabled ? 'Disable Feature' : 'Enable Feature';
    });
}); 
// Listen for messages from the background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'backgroundAction') {
        console.log('Received message in content script:', message.data);
        
        // Example: Modify the page content
        const div = document.createElement('div');
        div.style.position = 'fixed';
        div.style.top = '10px';
        div.style.right = '10px';
        div.style.padding = '10px';
        div.style.backgroundColor = '#f0f0f0';
        div.style.border = '1px solid #ccc';
        div.style.zIndex = '9999';
        div.textContent = 'Extension action performed: ' + message.data;
        
        document.body.appendChild(div);
        
        // Remove the notification after 3 seconds
        setTimeout(() => {
            div.remove();
        }, 3000);
        
        sendResponse({ result: 'Content script action completed' });
    }
    return true;
}); 
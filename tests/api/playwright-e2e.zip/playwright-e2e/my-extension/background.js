// Handle messages from popup or content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'performAction') {
        // Perform some action
        console.log('Performing action from background script');
        
        // Send message to content script
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: 'backgroundAction',
                data: 'Some data from background'
            });
        });

        // Send response back to popup
        sendResponse({ result: 'Action completed successfully' });
    }
    
    // Important: return true to indicate you want to send a response asynchronously
    return true;
}); 
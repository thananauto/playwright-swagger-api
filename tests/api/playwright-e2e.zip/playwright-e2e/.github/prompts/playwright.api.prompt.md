## API Test Generation Prompt using Playwright
**Input File:** Utilize the contents of the `pet.json` file to guide the API test generation using Playwright.

**Client Code:** All client interactions should leverage pre-existing code inside the Api.ts file. This file contains all predefined typed functions and types, so ensure you import from there.

**Code Generation:** Avoid generating any code from scratch. Use what's already defined in the `Api.ts` file.

**Assertions:** Implement assertions within the tests using Playwright's expect function to verify response status codes.

**Import Statements:** Include all necessary modules needed for the tests at the beginning of your test files.

**Test Organization:** Use the test.describe block to group similar types of tests together.

**Endpoint Tests:** For each API endpoint, create a corresponding test file named <endpoint-name>.spec.ts.

**Test File Storage:** Store and save all generated test files in the tests/api-new directory.
import { generateSpec } from "har-to-openapi";
///const generateSpec = require("har-to-openapi"); // Dynamically import the generateSpec function
import fs from 'fs'; // Import the 'fs' module for reading files

// Read the HAR file (replace with your actual file reading logic)

import { readFile } from 'node:fs';

const har = readFile('test1.har', (err, data) => {
  if (err) throw err;
  console.log(data);
});
const har1 = { 
  log: {
    entries: [
      {
        index: 0,
        request: {
          method: "GET",
          url: "https://example.com/api/users",
          headers: [],
        },
        response: {
            status: 200,
            headers: [],
            content: {
                mimeType: "application/json",
                text: "{ \"users\": [] }"
            }

        }
      }
    ]
  }
};

// Generate the OpenAPI spec
async function spec1(har) {
    return  await generateSpec(har, {
    forceAllRequestsInSameSpec: true, // Example option
    });

    const { spec, yamlSpec } = await openapi;

    //console.log(yamlSpec); // Output the YAML string

    fs.writeFileSync('openapi.yaml', yamlSpec); // Save the YAML spec to a file
    console.log('OpenAPI spec saved to openapi.yaml');
}

 

 spec1(har).then((result) => {
  const { spec, yamlSpec } = result 
   fs.writeFileSync('openapi.yaml', yamlSpec); // Save the YAML spec to a file
    console.log('OpenAPI spec saved to openapi.yaml');
  }).catch((error) => {
    console.error('Error generating OpenAPI spec:', error);
  });

 
const { chromium } = require('playwright');
const path = require('path');

(async () => {
  // Path to your extension directory
  const extensionPath = path.join(__dirname, 'my-extension');
  
  // Launch browser with extension
  const browser = await chromium.launchPersistentContext('user-data-dir', {
    headless: false,
    args: [
      `--disable-extensions-except=${extensionPath}`,
      `--load-extension=${extensionPath}`,
      '--enable-automation'
    ]
  });

  try {
    // Create a new page
    const page = await browser.newPage();

    // Get the extension background page
    const backgroundPages = browser.backgroundPages();
    const extensionBackgroundPage = backgroundPages[0];

    // Navigate to a page where you want to use the extension
    await page.goto('https://example.com');

    // Example: Click extension popup button (if exists in your browser toolbar)
    // Note: Extension popup needs to be handled differently as it's in a separate context
    const extensionButton = page.locator('xpath=//*[@id="extension-icon"]');
    if (await extensionButton.isVisible()) {
      await extensionButton.click();
    }

    // Example: Interact with extension popup
    // Get extension popup page
    const popupPage = await browser.waitForEvent('page', {
      predicate: page => page.url().startsWith('chrome-extension://')
    });

    // Interact with popup elements
    await popupPage.waitForLoadState('domcontentloaded');
    await popupPage.click('#some-button-in-popup');

    // Example: Send message to extension background script
    await extensionBackgroundPage.evaluate(() => {
      chrome.runtime.sendMessage({ action: 'someAction' });
    });

    // Example: Listen for extension events
    await extensionBackgroundPage.evaluate(() => {
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        console.log('Received message:', message);
        sendResponse({ received: true });
      });
    });

    // Keep browser open for demonstration
    await new Promise(resolve => setTimeout(resolve, 30000));

  } catch (error) {
    console.error('An error occurred:', error);
  } finally {
    await browser.close();
  }
})(); 
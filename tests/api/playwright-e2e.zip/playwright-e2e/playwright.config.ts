import { type Metadata, defineConfig, devices } from '@playwright/test';
import type { Credentials } from './tests/init/generic.data';
import { TestDataOptions } from './tests/init/data.fixture';
//import { matcher} from '@utility/custom.matcher1'

//expect.extend(matcher)

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
// require('dotenv').config();

/**
 * See https://playwright.dev/docs/test-configuration.
 * 
 */



const githubContext = JSON.parse(process.env.GITHUB_CONTEXT || '{}');
let metadata: Metadata = {}
if(githubContext.sha){
      metadata = {
        'revision.id': githubContext?.sha,
        'revision.author': githubContext.actor,
        'revision.email': githubContext.event?.pusher?.email,
        'revision.subject': githubContext.event?.head_commit?.message,
        'revision.timestamp': githubContext.event?.repository?.updated_at,
        'revision.link': githubContext.event?.repository?.commits_url,
        'ci.link': 'https://github.com/thananauto/playwright-tips-tricks/actions/runs/'+githubContext.run_id,
        'timestamp': new Date()
      }
}
const timestamp = new Date(Date.now())
  .toUTCString()
  .replace(/ /gi, "_")
  .replace(/:/gi, "")
  .replace(/,/gi, "");
export default defineConfig< TestDataOptions >({
  testDir: './tests',
  /* Run tests in files in parallel */
  fullyParallel: true,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? 2 : 0,
  metadata: metadata ,   
  /* Opt out of parallel tests on CI. */
  workers: process.env.CI ? 1 : undefined,
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: [ ['blob', { outputFile: `./blob-report/report-${timestamp}.zip` }],
  ['html', {open : 'on-failure' }], ['json', { outputFile: 'results.json' }]],
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    /* Base URL to use in actions like `await page.goto('/')`. */
     baseURL: 'https://ebay.de',
     headless: true,
    // credentials: {
    //    apikey: 'globalApiKey',
    //    secretkey: 'globalSecretKey'
   // },

    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    trace: 'on',
    browserName: 'chromium',
    screenshot: "only-on-failure",
    testIdAttribute: 'data-test',
    
    
  },

  /* Configure projects for major browsers */
  projects: [
   /* {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },

    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },

    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },*/

    /* Test against mobile viewports. */
    // {
    //   name: 'Mobile Chrome',
    //   use: { ...devices['Pixel 5'] },
    // },
    // {
    //   name: 'Mobile Safari',
    //   use: { ...devices['iPhone 12'] },
    // },

    /* Test against branded browsers. */
      /*{
       name: 'Microsoft Edge',
       use: { ...devices['Desktop Edge'], channel: 'msedge' },
    }
  */
    {
       name: 'API',
       
       dependencies: ['setup']
       //testMatch: 'api/**'
     },
     {
      name: 'UI',
      use: { 
        ...devices['Desktop Chrome'], 
        headless: false,
       // credentials:{
        //  apikey: 'uiApi',
        //  secretkey: 'uiSecret'
       // }
      },
      //testMatch: 'ui/**',
      dependencies : ['setup'],
      testIgnore: 'api/**',
      // Force run skipped tests
      grep: /.*/,
      grepInvert: undefined
     },
     {
      name: 'setup',
      testMatch: '**/setup.ts' ,
      teardown: 'cleanup'

     },
     {
      name: 'cleanup',
      testMatch: '**/teardown.ts'
     }
       
  ],

  /* Run your local dev server before starting the tests */
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://127.0.0.1:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
});

import { test, expect } from '@playwright/test';

test('search for playwright on Google', async ({ page }) => {
    // Navigate to Google
    await page.goto('https://www.google.com');
    
    // Wait for the search input to be visible
    await page.waitForSelector('textarea[name="q"]');
    
    // Type "playwright" into the search box
    await page.fill('textarea[name="q"]', 'playwright');
    
    // Press Enter to search
    await page.press('textarea[name="q"]', 'Enter');
    
    // Wait for search results
    await page.waitForSelector('#search');
    
    // Verify we're on the search results page
    await expect(page.url()).toContain('search?q=playwright');
}); 
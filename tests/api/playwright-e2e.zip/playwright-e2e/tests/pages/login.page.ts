import { Page, expect } from '@playwright/test'
import { Credentials } from '../init/generic.data'


export default class LoginPage {

    readonly page:Page
    readonly credentials:Credentials

  

    constructor(page:Page, credentials:Credentials){
        this.page = page
        this.credentials = credentials
    }

    async login(){
        await this.page.goto('/login')
        await this.page.getByLabel('api-key').fill(this.credentials.apikey)
        await this.page.getByLabel('secret-key').fill(this.credentials.secretkey)
        await this.page.getByRole('button', { name: 'Get In' }).click()
        await expect(this.page.getByRole('heading', { name: 'Welcome back!' })).toBeVisible()
    }
}
//ts-@check
import { test as setup, expect, chromium } from '@playwright/test'
const testdata = 'data/person.json'
import * as fs from 'fs'
const authfile = 'data/.auth/user.json'

setup.skip('Login to demoblaze.com', async( {},testInfo)=>{

    const project = testInfo.config.projects.filter((e: any) => e.__projectId == 'UI')
    setup.skip(project.length !=1, 'skip for non UI test')

    const context = (await (await chromium.launch({headless: true})).newContext())
    const page  = await context.newPage()
    await page.goto('https://demoblaze.com/')
    await page.getByRole('link', { name : 'Log in'}).click()

    await page.locator('#loginusername').fill('test')
    await page.locator('#loginpassword').fill('test')
    await page.getByRole('button', { name : 'Log in'}).click()
    await expect(page.getByRole('link', { name: 'Log out'})).toBeVisible()
    await page.context().storageState({ path : authfile })
    await page.close()
    await context.close()

})
setup.skip('Login to the sauce lab demo sites', async({ page }, testInfo )=>{

    const project = testInfo.config.projects.filter((e: any) => e.__projectId == 'UI')
    setup.skip(project.length !=1, 'skip for non UI test')

    await page.goto('https://www.saucedemo.com/')
    await page.getByRole('textbox', { name : 'Username'}).fill('standard_user')
    await page.getByRole('textbox', { name : 'Password'}).fill('secret_sauce')
    await page.getByRole('button', { name : 'Login'}).click()

    await expect(page.getByTestId('title')).toBeVisible()
    await page.context().storageState({ path: authfile})
})

setup('Setup the test data', async ({ request }, testInfo)=>{
    const project = testInfo.config.projects.filter((e: any) => e.__projectId == 'API')
    setup.skip(project.length !=1, 'skip for non UI test')
    const res = await request.get('https://api.restful-api.dev/objects')
    expect(res.status()).toBe(200)
    const op = JSON.stringify(await res.json())
    fs.writeFileSync(testdata, String(op), {flag: 'w'})

})

setup.skip('Authentication', async({ request })=>{

    const res = await request.post('https://the-internet.herokuapp.com/basic_auth',{
         form:{
             'user' : 'admin',
             'pass' : 'admin'
         }
     })
     expect(res.status()).toBe(200)
     await request.storageState({ path: authfile})

 })
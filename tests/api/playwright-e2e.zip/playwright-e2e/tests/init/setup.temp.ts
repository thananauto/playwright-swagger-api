import { test as setup, expect, chromium } from '@playwright/test'
const testdata = 'data/person.json'
import * as fs from 'fs'
const authfile = 'data/.auth/user.json'

setup('Login to demoblaze.com', async( {},testInfo)=>{
    const context = (await (await chromium.launch({headless: true})).newContext())
    const page  = await context.newPage()
    await page.goto('https://demoblaze.com/')
    await page.getByRole('link', { name : 'Log in'}).click()

    await page.locator('#loginusername').fill('test')
    await page.locator('#loginpassword').fill('test')
    await page.getByRole('button', { name : 'Log in'}).click()
    await expect(page.getByRole('link', { name: 'Log out'})).toBeVisible()
    await page.context().storageState({ path : authfile })
    await page.close()
    await context.close()
})

setup('Login to the sauce lab demo sites', async({ page }, testInfo )=>{
    await page.goto('https://www.saucedemo.com/')
    await page.getByRole('textbox', { name : 'Username'}).fill('standard_user')
    await page.getByRole('textbox', { name : 'Password'}).fill('secret_sauce')
    await page.getByRole('button', { name : 'Login'}).click()

    await expect(page.getByTestId('title')).toBeVisible()
    await page.context().storageState({ path: authfile})
})

setup('Authentication', async({ request })=>{
    const res = await request.post('https://the-internet.herokuapp.com/basic_auth',{
         form:{
             'user' : 'admin',
             'pass' : 'admin'
         }
     })
     expect(res.status()).toBe(200)
     await request.storageState({ path: authfile})
}) 
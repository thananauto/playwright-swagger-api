import { test as teardown } from '@playwright/test'


teardown.skip('Close the browser', async ({ browser })=>{
    console.log('closing database .......')
})  

export interface Credentials {
    apikey: string; 
    secretkey: string;
    
}

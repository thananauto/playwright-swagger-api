import { chromium } from 'playwright';
import type { Browser } from 'playwright';

import { test as base } from '@playwright/test';
import getPort from 'get-port';

 const lighthouse = base.extend<
  {},
  { port: number; browser: Browser }
>({
  port: [
    async ({}, use) => {
      // Assign a unique port for each playwright worker to support parallel tests
      const port = await getPort();
      await use(port);
    },
    { scope: 'worker' },
  ],

  context: [
    async ({ port }, use) => {
      const browser = await chromium.launch({
        args: [`--remote-debugging-port=${port}`],
      });
      const context = await browser.newContext();
      await use(context);
      await browser.close();
      
    },
    { scope: 'test' },
  ],
  page: [
    async ({ context }, use) => {
        const page = await context.newPage();
      await use(page);
      await page.close();
    },
    { scope: 'test' },
  ],
});

export { expect } from '@playwright/test';
export {lighthouse }

import { test as Base, expect } from '@playwright/test'
import fs from 'fs'
import path from 'path'

type state ={
    workerStorageState: string
}

 const test = Base.extend<{}, state>({
    //same file for each worker
    storageState: ({ workerStorageState}, use) => use(workerStorageState),

    workerStorageState:[ async({ browser }, use) =>{

        const id = test.info().parallelIndex
        const fileName = path.resolve(test.info().project.outputDir, `.auth/${id}.json`)

        //reuse the file if exists
        if(fs.existsSync(fileName)){
            await use(fileName)
        }

        const context = await browser.newContext({ storageState: undefined})
        const account = { username: 'test', password: 'test'}
        const page = await context.newPage()
    await page.goto('https://demoblaze.com/')
    await page.getByRole('link', { name : 'Log in'}).click()

    await page.locator('#loginusername').fill(account.username)
    await page.locator('#loginpassword').fill(account.password)
    await page.getByRole('button', { name : 'Log in'}).click()
    await expect(page.getByRole('link', { name: 'Log out'})).toBeVisible()
    await page.context().storageState({ path : fileName })
    await page.close()
    await context.close()

    await use(fileName)

    }, { scope: 'worker'}]
})

export { expect, test }
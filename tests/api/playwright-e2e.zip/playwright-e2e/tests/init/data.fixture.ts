import { test as dataFixture, expect } from '@playwright/test'
import  PomTemplate   from '../pages/pomTemplate'
import type { Credentials } from './generic.data'
import LoginPage from '../pages/login.page'


export type PageObjects ={
    loginPage: LoginPage
}

export type TestDataOptions = {
    credentials: Credentials
}
const test = dataFixture.extend< PageObjects & TestDataOptions >({
   credentials: [
        async ({}, use) => {
            const credentials: Credentials = {
                apikey: 'fixtureApiKey',
                secretkey: 'fixtureSecretKey',
            };
            await use(credentials);
        },
        { option: true },
    ],
    loginPage: [ async({ page, baseURL, credentials }, use)=>{
        await page.goto(baseURL as string)
        const loginPage = new LoginPage(page, credentials);
        await loginPage.login();
        await use(loginPage);
    }
    , { scope: 'test'}],
})



export { test, expect }
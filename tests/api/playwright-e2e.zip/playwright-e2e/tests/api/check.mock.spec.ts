import { test, expect } from '@playwright/test'

test.use({ baseURL: 'http://localhost:3000' })
test.describe('Check the playwright mock tests', async () => {
    test('Combine request and context', async ({ playwright }) => {
        const browser = await playwright.chromium.launch()
        const context = await browser.newContext()
        const page = await context.newPage()
        // const req =  context.request

        await page.route('/comments/3', async (route) => {
            // const  reponse = await req.fetch(route.request())
            //const resheaders = reponse.headers()
            await route.fulfill({
                status: 204,
                contentType: 'application/json',
                body: 'not found',
            })
        })
        await page.goto('/')
        const res = await page.request.get('/comments/3')
        // const res = await page.goto('/comments/3')
        expect(res.status()).toBe(204)
        // expect(await res.json())
    })

    test('Test the mock', async ({ request }) => {
        const res = await request.get('/comments')
        expect(res.status()).toBe(200)
        expect(await res.json())
    })
})

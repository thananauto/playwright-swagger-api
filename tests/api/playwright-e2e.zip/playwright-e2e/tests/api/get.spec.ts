import { expect, test } from '@playwright/test'

test.describe('Test the API request of book page', () => {
    test.use({ baseURL: 'https://api.restful-api.dev' })
    test('GET Operation', { tag: '@get' }, async ({ request }) => {
        type resId = {
            id: string
            name: string
            data: {}
        }

        const res = await request.get('/objects')
        expect(res.status()).toBe(200)

        test.step('Validate json response', async () => {
            await res?.json().then(async (ele) => {
                await Promise.all(
                    ele.map(async (element: resId) => {
                        if (element.data) {
                            expect(element.id).toBeTruthy()
                            expect(element.name).toMatch(/\S/)
                            expect(element.data).toBeTruthy()
                        }
                    })
                )
            })
        })
    })
})

import { test, expect } from '@playwright/test';
import { Pet } from '../../Api';

test.describe('Update Pet API', () => {
  test('should update an existing pet successfully', async ({ request }) => {
    const updatedPet: Pet = {
      id: 123,
      name: 'Updated Test Pet',
      photoUrls: ['http://example.com/photo.jpg'],
      status: 'sold',
    };

    const response = await request.put('/pet', {
      data: updatedPet,
    });

    expect(response.status()).toBe(200);
  });
});

import { test, expect } from '@playwright/test'
import person from '../../data/person.json' 

test.describe.configure({ mode: 'parallel' })

//test.use({ baseURL : 'https://api.restful-api.dev'})
test.describe('data driven', { tag: '@pw-data' }, async () => {
    type objperson = {
        id: string
        name: string
        data?: {}
    }

    await Promise.all(
        person.map((ele) => {
            test(`Device: ${ele.id}`, async ({ request }) => {
                let res = await request.get(
                    `https://api.restful-api.dev/objects/${ele.id}`
                )
                expect(res.status()).toBe(200)

                await res.json().then((e: objperson) => {
                    expect.soft(e.id).toBe(ele.id)
                    expect.soft(e.name).toBe(ele.name)
                })
            })
        })
    )
})

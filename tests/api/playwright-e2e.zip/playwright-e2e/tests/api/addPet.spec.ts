import { test, expect } from '@playwright/test';
import { Pet } from '../../Api';

test.describe('Add Pet API', () => {
  test('should add a new pet successfully', async ({ request }) => {
    const newPet: Pet = {
      id: 123,
      name: 'Test Pet',
      photoUrls: ['http://example.com/photo.jpg'],
      status: 'available',
    };

    const response = await request.post('/pet', {
      data: newPet,
    });

    expect(response.status()).toBe(200);
  });
});

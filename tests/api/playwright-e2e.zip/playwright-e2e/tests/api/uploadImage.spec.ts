import { test, expect } from '@playwright/test';
import { ApiResponse } from '../../Api';

test.describe('Upload Image API', () => {
  test('should upload an image successfully', async ({ request }) => {
    const petId = 123; // Example pet ID
    const response = await request.post(`/pet/${petId}/uploadImage`, {
      multipart: {
        additionalMetadata: 'Test metadata',
        file: { name: 'test-image.jpg', mimeType: 'image/jpeg', buffer: Buffer.from('') },
      },
    });

    expect(response.status()).toBe(200);
    const responseBody: ApiResponse = await response.json();
    expect(responseBody.code).toBeDefined();
    expect(responseBody.message).toBeDefined();
  });
});

import { test, expect } from '@playwright/test';
const baseUrl = 'http://api.practicesoftwaretesting.com';
const pathName = '/';
const pathUrl = '/categories/tree';
const endPoint = `${baseUrl}${pathName}${pathUrl}`;

test.describe('practicesoftwaretesting.com/ /categories/tree', () => {
  test('GET: Should return success', async ({ request }) => {
    const response = await request.get(`${endPoint}`, {
      headers: { 
         "Content-Type": "application/json",  },
    });
    expect(response.status()).toBe(200);
    expect(await response.json()).toEqual([
  {
    "id": "01JZNC8BXZNBDVNEZK0XS3JZH7",
    "name": "Hand Tools",
    "slug": "hand-tools",
    "parent_id": null,
    "sub_categories": [
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRD",
        "name": "Hammer",
        "slug": "hammer",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7",
        "sub_categories": []
      },
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRE",
        "name": "Hand Saw",
        "slug": "hand-saw",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7",
        "sub_categories": []
      },
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRF",
        "name": "Wrench",
        "slug": "wrench",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7",
        "sub_categories": []
      },
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRG",
        "name": "Screwdriver",
        "slug": "screwdriver",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7",
        "sub_categories": []
      },
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRH",
        "name": "Pliers",
        "slug": "pliers",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7",
        "sub_categories": []
      },
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRJ",
        "name": "Chisels",
        "slug": "chisels",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7",
        "sub_categories": []
      },
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRK",
        "name": "Measures",
        "slug": "measures",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7",
        "sub_categories": []
      }
    ]
  },
  {
    "id": "01JZNC8BXZNBDVNEZK0XS3JZH8",
    "name": "Power Tools",
    "slug": "power-tools",
    "parent_id": null,
    "sub_categories": [
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRM",
        "name": "Grinder",
        "slug": "grinder",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH8",
        "sub_categories": []
      },
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRN",
        "name": "Sander",
        "slug": "sander",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH8",
        "sub_categories": []
      },
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRP",
        "name": "Saw",
        "slug": "saw",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH8",
        "sub_categories": []
      },
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRQ",
        "name": "Drill",
        "slug": "drill",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH8",
        "sub_categories": []
      }
    ]
  },
  {
    "id": "01JZNC8BXZNBDVNEZK0XS3JZH9",
    "name": "Other",
    "slug": "other",
    "parent_id": null,
    "sub_categories": [
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRR",
        "name": "Tool Belts",
        "slug": "tool-belts",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH9",
        "sub_categories": []
      },
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRS",
        "name": "Storage Solutions",
        "slug": "storage solutions",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH9",
        "sub_categories": []
      },
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRT",
        "name": "Workbench",
        "slug": "workbench",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH9",
        "sub_categories": []
      },
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRV",
        "name": "Safety Gear",
        "slug": "safety-gear",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH9",
        "sub_categories": []
      },
      {
        "id": "01JZNC8BYKHBMM1AE144QGJDRW",
        "name": "Fasteners",
        "slug": "fasteners",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH9",
        "sub_categories": []
      }
    ]
  }
]);
  });
});

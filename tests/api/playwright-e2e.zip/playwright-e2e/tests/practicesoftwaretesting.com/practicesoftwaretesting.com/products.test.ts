import { test, expect } from '@playwright/test';
const baseUrl = 'http://api.practicesoftwaretesting.com';
const pathName = '/';
const pathUrl = '/products';
const endPoint = `${baseUrl}${pathName}${pathUrl}`;

test.describe('practicesoftwaretesting.com/ /products', () => {
  test('GET: Should return success', async ({ request }) => {
    const response = await request.get(`${endPoint}`, {
      headers: {"Content-Type": "application/json" },params: {page:1, between:"price,1,100"},
    });
    expect(response.status()).toBe(200);
    expect(await response.json()).toEqual({
  "current_page": 1,
  "data": [
    {
      "id": "01JZNC8C0A3YKRMH3X32Q9R6DV",
      "name": "Combination Pliers",
      "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris viverra felis nec pellentesque feugiat. Donec faucibus arcu maximus, convallis nisl eu, placerat dolor. Morbi finibus neque nec tincidunt pharetra. Sed eget tortor malesuada, mollis enim id, condimentum nisi. In viverra quam at bibendum ultricies. Aliquam quis eros ex. Etiam at pretium massa, ut pharetra tortor. Sed vel metus sem. Suspendisse ac molestie turpis. Duis luctus justo massa, faucibus ornare eros elementum et. Vestibulum quis nisl vitae ante dapibus tempor auctor ut leo. Mauris consectetur et magna at ultricies. Proin a aliquet turpis.",
      "price": 14.15,
      "is_location_offer": false,
      "is_rental": false,
      "in_stock": true,
      "product_image": {
        "id": "01JZNC8BZEAVMJESJKGPKW4XKZ",
        "by_name": "Helinton Fantin",
        "by_url": "https://unsplash.com/@fantin",
        "source_name": "Unsplash",
        "source_url": "https://unsplash.com/photos/W8BNwvOvW4M",
        "file_name": "pliers01.avif",
        "title": "Combination pliers"
      },
      "category": {
        "id": "01JZNC8BYKHBMM1AE144QGJDRH",
        "name": "Pliers",
        "slug": "pliers",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7"
      },
      "brand": {
        "id": "01JZNC8BJSMVHFSQRVWEQKWFK0",
        "name": "ForgeFlex Tools",
        "slug": "forgeflex-tools"
      }
    },
    {
      "id": "01JZNC8C0EEB8HKXQEGNE72XW9",
      "name": "Pliers",
      "description": "Nunc vulputate, orci at congue faucibus, enim neque sodales nulla, nec imperdiet augue odio vel nibh. Etiam auctor, ligula quis gravida dictum, mi massa commodo ante, sollicitudin pulvinar nulla justo hendrerit lacus. Vivamus rutrum pharetra molestie. Fusce tristique odio tristique, elementum est eget, porttitor diam. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Maecenas at ligula sed sapien porta pretium. Aenean cursus, magna in blandit consectetur, libero orci aliquet eros, et maximus nunc est eu dolor. Aenean non pellentesque eros. In sodales orci eget orci fringilla, vitae feugiat elit porta. Etiam aliquam, mi pretium tempus mattis, mauris ipsum gravida risus, at tempor nulla ipsum molestie ligula. Ut placerat, urna sit amet tincidunt volutpat, ex orci luctus purus, nec laoreet dolor sapien vel erat.",
      "price": 12.01,
      "is_location_offer": false,
      "is_rental": false,
      "in_stock": true,
      "product_image": {
        "id": "01JZNC8BZEAVMJESJKGPKW4XM0",
        "by_name": "Everyday basics",
        "by_url": "https://unsplash.com/@zanardi",
        "source_name": "Unsplash",
        "source_url": "https://unsplash.com/photos/I8eTuMmxIfo",
        "file_name": "pliers02.avif",
        "title": "Pliers"
      },
      "category": {
        "id": "01JZNC8BYKHBMM1AE144QGJDRH",
        "name": "Pliers",
        "slug": "pliers",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7"
      },
      "brand": {
        "id": "01JZNC8BJSMVHFSQRVWEQKWFK0",
        "name": "ForgeFlex Tools",
        "slug": "forgeflex-tools"
      }
    },
    {
      "id": "01JZNC8C0GFPH136AJFRGY6XRX",
      "name": "Bolt Cutters",
      "description": "Aliquam viverra scelerisque tempus. Ut vehicula, ex sed elementum rhoncus, sem neque vehicula turpis, sit amet accumsan mauris justo non magna. Cras ut vulputate lectus, sit amet sollicitudin enim. Quisque sit amet turpis ut orci pulvinar vestibulum non at velit. Quisque ultrices malesuada felis non rutrum. Sed molestie lobortis nisl, in varius arcu dictum vel. In sit amet fringilla orci. Quisque ac magna dui. Nam pulvinar nulla sed commodo ultricies. Suspendisse aliquet quis eros sit amet gravida. Aenean vitae arcu in sapien sodales commodo.",
      "price": 48.41,
      "is_location_offer": true,
      "is_rental": false,
      "in_stock": true,
      "product_image": {
        "id": "01JZNC8BZEAVMJESJKGPKW4XM1",
        "by_name": "Michael Dziedzic",
        "by_url": "https://unsplash.com/@lazycreekimages",
        "source_name": "Unsplash",
        "source_url": "https://unsplash.com/photos/pM9pkc9J918",
        "file_name": "pliers03.avif",
        "title": "Bolt cutters"
      },
      "category": {
        "id": "01JZNC8BYKHBMM1AE144QGJDRH",
        "name": "Pliers",
        "slug": "pliers",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7"
      },
      "brand": {
        "id": "01JZNC8BJSMVHFSQRVWEQKWFK1",
        "name": "MightyCraft Hardware",
        "slug": "mightycraft-hardware"
      }
    },
    {
      "id": "01JZNC8C0JKGN61QY7KZPCH5Y3",
      "name": "Long Nose Pliers",
      "description": "Phasellus consequat fermentum quam id sodales. Curabitur nec dui orci. Fusce id turpis laoreet, lobortis ex non, finibus libero. Vivamus id enim eu nibh placerat maximus. Aenean semper dui a laoreet venenatis. Vestibulum at ligula quam. Donec interdum tristique neque lacinia laoreet. Sed auctor fermentum congue. Integer aliquet vulputate feugiat. Quisque malesuada diam iaculis ornare maximus. Mauris quam massa, sodales at mattis non, consectetur eget magna. Aliquam eget congue metus, sed congue leo. Nam sit amet est id ligula volutpat pharetra non id nisl. Vestibulum ac enim vitae nisi tempus cursus. Aliquam erat volutpat.",
      "price": 14.24,
      "is_location_offer": false,
      "is_rental": false,
      "in_stock": false,
      "product_image": {
        "id": "01JZNC8BZEAVMJESJKGPKW4XM2",
        "by_name": "Brett Jordan",
        "by_url": "https://unsplash.com/@brett_jordan",
        "source_name": "Unsplash",
        "source_url": "https://unsplash.com/photos/GamuDTVm02g",
        "file_name": "pliers04.avif",
        "title": "Long nose pliers"
      },
      "category": {
        "id": "01JZNC8BYKHBMM1AE144QGJDRH",
        "name": "Pliers",
        "slug": "pliers",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7"
      },
      "brand": {
        "id": "01JZNC8BJSMVHFSQRVWEQKWFK1",
        "name": "MightyCraft Hardware",
        "slug": "mightycraft-hardware"
      }
    },
    {
      "id": "01JZNC8C0MTH3VAFD9F94HPKQV",
      "name": "Slip Joint Pliers",
      "description": "Ut cursus dui non ante convallis, facilisis auctor leo luctus. Maecenas a rhoncus metus. Sed in efficitur dolor, vulputate accumsan odio. Sed ex quam, dictum in fringilla at, vestibulum eu sem. Quisque ante orci, vulputate non porttitor eu, aliquet et nunc. Nunc a rhoncus dui. Nunc ac est non eros scelerisque maximus at a eros. Phasellus sed egestas diam, at tempus erat. Morbi sit amet congue tellus, at accumsan magna. Etiam non ornare nisl, sed luctus nisi. Pellentesque ut odio ut sapien aliquet eleifend.",
      "price": 9.17,
      "is_location_offer": false,
      "is_rental": false,
      "in_stock": true,
      "product_image": {
        "id": "01JZNC8BZEAVMJESJKGPKW4XM3",
        "by_name": "Yasin Hasan",
        "by_url": "https://unsplash.com/@yasin",
        "source_name": "Unsplash",
        "source_url": "https://unsplash.com/photos/dwlxTSpfKXg",
        "file_name": "pliers05.avif",
        "title": "Slip joint pliers"
      },
      "category": {
        "id": "01JZNC8BYKHBMM1AE144QGJDRH",
        "name": "Pliers",
        "slug": "pliers",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7"
      },
      "brand": {
        "id": "01JZNC8BJSMVHFSQRVWEQKWFK1",
        "name": "MightyCraft Hardware",
        "slug": "mightycraft-hardware"
      }
    },
    {
      "id": "01JZNC8C0PQV70S464BWGE8CBV",
      "name": "Claw Hammer with Shock Reduction Grip",
      "description": "Nam efficitur, turpis molestie bibendum lobortis, risus arcu congue tortor, id consequat nibh sem a libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean non tincidunt tortor, vel ultricies tortor. Vivamus pulvinar efficitur arcu sit amet accumsan. Aenean dui erat, bibendum at dapibus in, feugiat non eros. Duis sodales felis ex, quis ullamcorper odio interdum non. Ut viverra magna eu augue luctus, quis convallis lectus auctor. Duis ultrices erat urna. Aliquam augue odio, mattis vitae finibus in, pellentesque nec dui. Curabitur nec odio in augue posuere posuere. Vivamus ante est, iaculis ut interdum et, hendrerit ac ante. Fusce ac venenatis neque, id fermentum nulla. Quisque tristique ornare nisi, vitae convallis dui faucibus quis. Vestibulum vel dapibus dolor.",
      "price": 13.41,
      "is_location_offer": true,
      "is_rental": false,
      "in_stock": true,
      "product_image": {
        "id": "01JZNC8BZEAVMJESJKGPKW4XM4",
        "by_name": "iMattSmart",
        "by_url": "https://unsplash.com/@imattsmart",
        "source_name": "Unsplash",
        "source_url": "https://unsplash.com/photos/jaLaLQdkBOE",
        "file_name": "hammer01.avif",
        "title": "Claw Hammer"
      },
      "category": {
        "id": "01JZNC8BYKHBMM1AE144QGJDRD",
        "name": "Hammer",
        "slug": "hammer",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7"
      },
      "brand": {
        "id": "01JZNC8BJSMVHFSQRVWEQKWFK0",
        "name": "ForgeFlex Tools",
        "slug": "forgeflex-tools"
      }
    },
    {
      "id": "01JZNC8C0R5GNZNMSR597V2YWR",
      "name": "Hammer",
      "description": "Mauris mollis odio est, ac vehicula dui lobortis vel. Cras facilisis, mauris ut vehicula dignissim, ex nunc sollicitudin velit, a fermentum mi odio ut massa. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent a sapien vel libero fermentum rhoncus. Etiam ac imperdiet arcu, ac accumsan risus. Fusce vitae lacinia sem, sit amet sagittis lorem. Curabitur efficitur ultricies sem, eu placerat ante tincidunt a. Morbi faucibus ullamcorper mi a mollis. Aenean sed magna aliquam, mollis dui at, condimentum ex. Donec blandit bibendum enim, lacinia vestibulum tellus laoreet sollicitudin. In vitae ullamcorper metus, ut interdum augue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nullam scelerisque dignissim varius. Nulla facilisi. Praesent eros dolor, ultricies sit amet pellentesque porttitor, pretium ut lectus. Nullam tempus tellus sapien, non condimentum mauris volutpat eget.",
      "price": 12.58,
      "is_location_offer": false,
      "is_rental": false,
      "in_stock": true,
      "product_image": {
        "id": "01JZNC8BZEAVMJESJKGPKW4XM5",
        "by_name": "Jozsef Hocza",
        "by_url": "https://unsplash.com/@hocza",
        "source_name": "Unsplash",
        "source_url": "https://unsplash.com/photos/D3nouOYbALc",
        "file_name": "hammer02.avif",
        "title": "Hammer"
      },
      "category": {
        "id": "01JZNC8BYKHBMM1AE144QGJDRD",
        "name": "Hammer",
        "slug": "hammer",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7"
      },
      "brand": {
        "id": "01JZNC8BJSMVHFSQRVWEQKWFK0",
        "name": "ForgeFlex Tools",
        "slug": "forgeflex-tools"
      }
    },
    {
      "id": "01JZNC8C0T3MH3W9V51Q38AKP3",
      "name": "Claw Hammer",
      "description": "Cras pulvinar nisl a quam fringilla tempus. Sed lectus urna, mattis quis arcu eget, aliquam laoreet mauris. Praesent accumsan facilisis eros, ac mattis nulla interdum nec. Phasellus ultrices eu metus in lobortis. Donec ac efficitur orci. Phasellus nulla neque, congue nec tincidunt id, ultrices vel sapien. Curabitur gravida ex leo, laoreet mollis arcu blandit vel.",
      "price": 11.48,
      "is_location_offer": true,
      "is_rental": false,
      "in_stock": true,
      "product_image": {
        "id": "01JZNC8BZEAVMJESJKGPKW4XM6",
        "by_name": "Andrew George",
        "by_url": "https://unsplash.com/@andrewjoegeorge",
        "source_name": "Unsplash",
        "source_url": "https://unsplash.com/photos/YU2mCvXR0wA",
        "file_name": "hammer03.avif",
        "title": "Claw Hammer"
      },
      "category": {
        "id": "01JZNC8BYKHBMM1AE144QGJDRD",
        "name": "Hammer",
        "slug": "hammer",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7"
      },
      "brand": {
        "id": "01JZNC8BJSMVHFSQRVWEQKWFK1",
        "name": "MightyCraft Hardware",
        "slug": "mightycraft-hardware"
      }
    },
    {
      "id": "01JZNC8C0V7220ZMA5H9BC8G5Q",
      "name": "Thor Hammer",
      "description": "Donec malesuada tempus purus. Integer sit amet arcu magna. Sed vel laoreet ligula, non sollicitudin ex. Mauris euismod ac dolor venenatis lobortis. Aliquam iaculis at diam nec accumsan. Ut sodales sed elit et imperdiet. Maecenas vitae molestie mauris. Integer quis placerat libero, in finibus diam. Interdum et malesuada fames ac ante ipsum primis in faucibus.",
      "price": 11.14,
      "is_location_offer": false,
      "is_rental": false,
      "in_stock": true,
      "product_image": {
        "id": "01JZNC8BZEAVMJESJKGPKW4XM7",
        "by_name": "ANIRUDH",
        "by_url": "https://unsplash.com/@lanirudhreddy",
        "source_name": "Unsplash",
        "source_url": "https://unsplash.com/photos/3esjG-nlgyk",
        "file_name": "hammer04.avif",
        "title": "Hammer"
      },
      "category": {
        "id": "01JZNC8BYKHBMM1AE144QGJDRD",
        "name": "Hammer",
        "slug": "hammer",
        "parent_id": "01JZNC8BXZNBDVNEZK0XS3JZH7"
      },
      "brand": {
        "id": "01JZNC8BJSMVHFSQRVWEQKWFK0",
        "name": "ForgeFlex Tools",
        "slug": "forgeflex-tools"
      }
    }
  ],
  "from": 1,
  "last_page": 5,
  "per_page": 9,
  "to": 9,
  "total": 45
});
  });
});

import { test, expect } from '@playwright/test';
const baseUrl = 'http://api.practicesoftwaretesting.com';
const pathName = '/';
const pathUrl = '/brands';
const endPoint = `${baseUrl}${pathName}${pathUrl}`;

test.describe('practicesoftwaretesting.com/ /brands', () => {
  test('GET: Should return success', async ({ request }) => {
    const response = await request.get(`${endPoint}`, {
      headers : { 
        "Accept": "example", 
        "Accept-Encoding": "example", 
        "Accept-Language": "123.45", 
        "Connection": "example", 
        "Content-Type": "example", 
        "Host": "example", 
        "Origin": "example", 
        "Referer": "example", 
        "Sec-Fetch-Dest": "example", 
        "Sec-Fetch-Mode": "example", 
        "Sec-Fetch-Site": "example", 
        "User-Agent": "123.45", 
        "sec-ch-ua": "example", 
        "sec-ch-ua-mobile": "example", 
        "sec-ch-ua-platform": "example" 
      },
    });
    expect(response.status()).toBe(200);
    expect(await response.json()).toEqual([
  {
    "id": "01JZNC8BJSMVHFSQRVWEQKWFK0",
    "name": "ForgeFlex Tools",
    "slug": "forgeflex-tools"
  },
  {
    "id": "01JZNC8BJSMVHFSQRVWEQKWFK1",
    "name": "MightyCraft Hardware",
    "slug": "mightycraft-hardware"
  },
  {
    "id": "01jznch106yv1rwz6wypnd9nef",
    "name": "new brand",
    "slug": "new-brand906"
  }
]);
  });
});

import { test, expect } from '@playwright/test';
const baseUrl = 'http://api.practicesoftwaretesting.com';
const pathName = '/';
const pathUrl = '/users/me';
const endPoint = `${baseUrl}${pathName}${pathUrl}`;

test.describe('practicesoftwaretesting.com/ /users/me', () => {
  test('GET: Should return success', async ({ request }) => {
    const response = await request.get(`${endPoint}`,  {
      headers: { 
        "Accept": "example", 
        "Accept-Encoding": "example", 
        "Accept-Language": "example", 
        "Connection": "example", 
        "Content-Type": "example", 
        "Host": "example", 
        "Origin": "example", 
        "Referer": "example", 
        "Sec-Fetch-Dest": "example", 
        "Sec-Fetch-Mode": "example", 
        "Sec-Fetch-Site": "example", 
        "User-Agent": "example", 
        "sec-ch-ua": "example", 
        "sec-ch-ua-mobile": "example", 
        "sec-ch-ua-platform": "example" 
      },
    });
    expect(response.status()).toBe(200);
  });
});

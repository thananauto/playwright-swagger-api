import { test, expect } from '@playwright/test';
import { Api } from '../../Api';

test.describe('Update Pet API Tests', () => {
  test('should update an existing pet successfully', async () => {
    const apiInstance = new Api();
    const updatedPet = {
      id: 12345,
      name: 'Buddy Updated',
      photoUrls: ['http://example.com/photo_updated.jpg'],
      status: 'pending' as 'pending',
    };

    const response = await apiInstance.pet.updatePet(updatedPet);

    expect(response.status).toBe(200);
    expect(response.data).toBeDefined();
  });

  test('should return error for invalid pet data', async () => {
    const apiInstance = new Api();
    const invalidPet = {
      id: -1,
      name: '',
      photoUrls: [],
      status: 'invalidStatus' as unknown as 'pending',
    };

    const response = await apiInstance.pet.updatePet(invalidPet);

    expect(response.status).toBe(400);
    expect(response.data).toBeUndefined();
  });
});

import { test, expect } from '@playwright/test';
import { Api } from '../../Api';

test.describe('Find Pets By Status API Tests', () => {
  test('should find pets by status successfully', async () => {
    const apiInstance = new Api();
    const status = ['available', 'pending'] as ('available' | 'pending' | 'sold')[];

    const response = await apiInstance.pet.findPetsByStatus({ status });

    expect(response.status).toBe(200);
    expect(response.data).toBeDefined();
    expect(response.data.length).toBeGreaterThan(0);
  });

  test('should return error for invalid status', async () => {
    const apiInstance = new Api();
    const status = ['invalidStatus'] as unknown as ('available' | 'pending' | 'sold')[];

    const response = await apiInstance.pet.findPetsByStatus({ status });

    expect(response.status).toBe(400);
    expect(response.data).toBeUndefined();
  });
});

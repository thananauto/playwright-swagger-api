import { test, expect } from '@playwright/test';
import { Api } from '../../Api';

test.describe('Upload File API Tests', () => {
  test('should upload a file successfully', async () => {
    const apiInstance = new Api();
    const petId = 12345; // Example pet ID
    const additionalMetadata = 'Sample metadata';
    const file = new File(['content'], 'example.jpg', { type: 'image/jpeg' });

    const response = await apiInstance.pet.uploadFile(petId, {
      additionalMetadata,
      file,
    });

    expect(response.status).toBe(200);
    expect(response.data).toBeDefined();
  });

  test('should return error for invalid pet ID', async () => {
    const apiInstance = new Api();
    const petId = -1; // Invalid pet ID
    const additionalMetadata = 'Sample metadata';
    const file = new File(['content'], 'example.jpg', { type: 'image/jpeg' });

    const response = await apiInstance.pet.uploadFile(petId, {
      additionalMetadata,
      file,
    });

    expect(response.status).toBe(400);
    expect(response.data).toBeUndefined();
  });
});

import { test, expect } from '@playwright/test';
import { Api } from '../../Api';

test.describe('Add Pet API Tests', () => {
  test('should add a new pet successfully', async () => {
    const apiInstance = new Api();
    const newPet = {
      id: 12345,
      name: 'Buddy',
      photoUrls: ['http://example.com/photo.jpg'],
      status: 'available' as 'available',
    };

    const response = await apiInstance.pet.addPet(newPet);

    expect(response.status).toBe(200);
    expect(response.data).toBeDefined();
  });

  test('should return error for invalid pet data', async () => {
    const apiInstance = new Api();
    const invalidPet = {
      id: -1,
      name: '',
      photoUrls: [],
      status: 'invalidStatus' as unknown as 'available',
    };

    const response = await apiInstance.pet.addPet(invalidPet);

    expect(response.status).toBe(405);
    expect(response.data).toBeUndefined();
  });
});

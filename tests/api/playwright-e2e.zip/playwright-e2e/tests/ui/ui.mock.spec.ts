import { request, test, expect } from "@playwright/test";

test.use({baseURL: 'https://practicesoftwaretesting.com'})
test.describe('Mock the brand and category', () => {

    test('Check the Product listing page', async ({ page, request }) => {

        await page.route('https://api.practicesoftwaretesting.com/categories/tree', async(route)=>{
            
                const response = await route.fetch();
                const mockres = await request.get('http://localhost:3001/brands')
                const mockJson = await mockres.json()
                await route.fulfill({ response:response, json:mockJson});
                

        })
        await page.goto('/')

        await expect(page.getByRole('textbox', { name: 'Search'})).toBeVisible()
        await page.pause()

    })
    
    
})

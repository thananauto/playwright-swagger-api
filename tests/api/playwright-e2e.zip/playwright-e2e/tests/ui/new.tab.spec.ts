import {test, expect, TestInfo, type Page, type BrowserContext } from '@playwright/test'
import { debug } from 'console'
import exp from 'constants'



test.describe('Check UI fucntionality',{ tag: '@ui'}, async() => {
 

let page: Page
let context: BrowserContext


test.beforeAll('launch the context', async({ browser })=>{
    context = await browser.newContext({ baseURL: 'https://practicesoftwaretesting.com/'})
})

test.afterAll('close the context', async({})=>{
    await context.close()
})
test.beforeEach('Launch the applicaiton',async ({ }, testInfo:TestInfo) => {

  page = await context.newPage()
 await page.goto('#/')
 await expect(page).toHaveURL(/practice/)
  
});

test.afterEach('close the context and browser', async({browser})=>{
   
    
    await page.close()
   
    //await browser.close()
})


test('has a page title', async ({ }) => {
    await expect(page).toHaveTitle('Practice Software Testing - Toolshop - v5.0')
    
});


test('open a new tab', async ({})=>{
    const [newPage] = await Promise.all([
    
         context.waitForEvent('page'),
         page.getByRole('link', { name: 'Unsplash', exact: true}).click(),
         
    ])
    const [newPage1] = await Promise.all([
        context.waitForEvent('page'),
        page.getByRole('link', { name: 'GitHub repo', exact: true}).click()
   ])

   
  
    await expect(newPage.getByRole('link', { name: 'Barn Images'})).toBeVisible()
    await newPage.close()
    await page.getByRole('link', {name: 'Contact'}).click()
    await expect(page.getByRole('heading', { name: 'Contact'})).toBeVisible()

})

test('Drag the slider', async ({  }) => {

    await page.waitForLoadState()
    const maxslider = page.getByRole('slider', {name: 'ngx-slider-max'})
    const minslider = page.getByRole('slider', {name: 'ngx-slider', exact: true})
    //using the click the method
    //await maxslider.click({
   //    force : true,
    //    position:{
    //        x: 60, y:0
    //    }
   // })

   await page.waitForTimeout(1000)
    //using mouse hover
    await maxslider.hover({ force: true, position: { x:0, y:0 }})
    await page.mouse.down()
    await page.mouse.move(283,0)
    await page.mouse.up()

    await page.waitForTimeout(1000)
    let {x, y} = await minslider.evaluate( ele =>{
        return ele.getBoundingClientRect()
    })
    await minslider.hover({ force: true, position: { x:0, y:0 }})
    await page.mouse.down()
    await page.waitForTimeout(1000)
    await minslider.hover({ force: true, position: { x:283, y:0 }})
    await page.mouse.up()

   
    //await page.pause()
    
})


})

import { expect, test } from "@playwright/test";


test.describe.configure({  mode: 'parallel'})
test.use({ 
    baseURL: 'https://the-internet.herokuapp.com/', 
    launchOptions:{
         args: ['--start-maximized']
        },
    headless: false})
test.describe('Javascript alerts', async( )=>{

    
    test('JS Alert', async({ page })=>{
        page.on('dialog', dialog=> {
            dialog.accept()
        })
        await page.goto('/')
        await page.getByText('JavaScript Alerts').click()
        await page.getByRole('button', { name : 'Click for JS Alert'}).click()
        await expect(page.getByText('You successfully clicked an alert')).toBeVisible()   
        
    })

    test('JS Cancel', async({ page })=>{
        page.on('dialog', dialog=> {
            dialog.dismiss()
        })
        await page.goto('/')
        await page.getByText('JavaScript Alerts').click()
        await page.getByRole('button', { name : 'Click for JS Confirm'}).click()
        await expect(page.getByText('You clicked: Cancel')).toBeVisible()

    })

    test('JS Promt with - text', async({ page })=>{
        const msg: string = 'hello world'
        page.on('dialog', dialog=> {   
            dialog.accept(msg)
        })
        await page.goto('/')
        await page.getByText('JavaScript Alerts').click()
        await page.getByRole('button', { name : 'Click for JS Prompt'}).click()
        await expect(page.locator('#result')).
        toContainText(msg)


    })


    test('Horizontal slider', async({ page })=>{

        await page.goto('/')
        await page.getByText('Horizontal Slider').click()
        await expect(page.locator('h3:has-text("Horizontal Slider")')).toBeVisible()

        const slider = page.locator('input[type="range"]')
        await slider.evaluate(node =>{
            (node as HTMLInputElement).value = '4'
            node.dispatchEvent(new Event('change'))
        })

        await expect(page.locator('#range')).toHaveText('4')
    })


    test('Drag and drop', async({ page })=>{

        await page.goto('/')
        await page.getByText('Drag and Drop').click()
        await expect(page.locator('h3:has-text("Drag and Drop")')).toBeVisible()

        const A = page.locator('div#column-a')
        const B = page.locator('div#column-b')

        await A.dragTo(B)
        await expect(page.locator('header').first()).toHaveText('B')
        await expect(page.locator('header').last()).toHaveText('A')

    })

    test('Drag and drop - manual', async({ page })=>{

        await page.goto('/')
        await page.getByText('Drag and Drop').click()
        await expect(page.locator('h3:has-text("Drag and Drop")')).toBeVisible()

        const A = page.locator('div#column-a')
        const B = page.locator('div#column-b')

        await A.hover()
        await page.mouse.down()
        await page.mouse.move(45,67, { steps: 2}) // based on (x,y) co-ordinates
        await page.mouse.up()

        await expect(page.locator('header').first()).toHaveText('B')
        await expect(page.locator('header').last()).toHaveText('A')

    })


   
})

test.use({baseURL: 'https://www.bupa.com', channel: 'chrome' })
test.describe('Star', () => {
    

test('Locator handler', async({ browser })=>{
    //set up a handler, close the cookie popup
    const context = await browser.newContext()
    const page = await context.newPage()
    await page.addLocatorHandler(page.locator('.cookie-btn'), async()=>{
        await page.locator('#cc-acceptAll-btn').click()
    }, { times: 1 })

    await page.goto('/')
    const mission = page.getByRole('button', { name: 'Our sustainability missions' })
    await mission.scrollIntoViewIfNeeded()
    await mission.click()
    await page.waitForLoadState('domcontentloaded')
    await expect(page).toHaveURL(/our-sustainability-missions/)
    
})
})

test.use({baseURL: 'https://www.starhealth.in',  channel: 'chrome' })
test.describe('Star health', () => {

test('Add css', async({ browser })=>{

    const context = await browser.newContext();
    const page = await context.newPage()
    //set up a handler, close the cookie popup
    page.on('dialog',  popup=> {
        console.log(popup.message());
         popup.accept();
       
    })
    await page.addLocatorHandler(page.locator('header:has-text("Welcome to STAR HEALTH")'), async()=>{
        await page.getByLabel('Close').click()
    }, { times: 1 })

    await page.goto('/')
    await page.waitForLoadState('load')
    const supportService = page.locator('span:has-text("Support")')
    //await expect(supportService).not.to()
    await expect(supportService).toBeVisible()

    await supportService.evaluate(node =>{
            console.log('come inside');
            
        (node as HTMLElement).style.transform='translateX(-150px)';
    })

    await expect(supportService).toBeVisible()

    await supportService.click()

    await page.getByRole('button', { name: 'Get Quote' }).click()

    await page.getByRole('link', { name: 'Quick Ship"'}).click()

    
})
})


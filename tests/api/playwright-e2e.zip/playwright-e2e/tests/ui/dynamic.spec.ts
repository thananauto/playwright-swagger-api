
import { test } from './../init/pageFixture'


test.describe('Dynamic loading of class files', async() => {
    
    test('Dynamic English - eBay Dynamic', async ({ dynamicPage }) => {
        await dynamicPage.searchAnItem('Barbie Doll')
        await dynamicPage.waitToOpenInNewTab()
        await dynamicPage.buyItNow()
        await dynamicPage.enterShippingAddressAndSubmit({})
        
    })
/*
    test('English - eBay', async ({ page }) => {
        await page.goto('/')
        const eng = new BuyItemInEnglish(page)
        await eng.searchAnItem('Barbie Doll')
        await eng.waitToOpenInNewTab()
        await eng.buyItNow()
        await eng.enterShippingAddress({})
        
    })

    test('DE - eBay', async ({ page }) => {
        await page.goto('/')
        const eng = new BuyItemInGermany(page)
        await eng.searchAnItem('Barbie Doll')
        await eng.waitToOpenInNewTab()
        await eng.buyItNow()
        await eng.enterShippingAddress({})
        
    })

    test('DE - eBay1', async ({ page }) => {
        await page.goto('/')
        const pageLanguage = await page.evaluate(() => document.documentElement.lang || "Not set");
        console.log(pageLanguage)

        
    })*/
    
    
})

import { test, expect } from '@playwright/test'


const authfile = 'data/.auth/user.json'

test.describe('User actions on Heroku APP', { tag: '@ui-one'},  async() => {
    test.use({
        baseURL : 'https://the-internet.herokuapp.com'
        //storageState: authfile
    })

    test('Event Listener', async ({ page, request }) => {
        
        
        await page.route('**/*', async(route,  request)=>{
            
           if(request.headers()['accept'].includes('text/html')){
            const headers = {
                ...request.headers(),
                foo: 'chumma',
                bar: 'gummala'
            }
            console.log(headers)
            return route.continue({headers: headers})

           }
           return route.continue()
        })
        
       // page.on('request', request => console.log(`Request sent: ${request.url()}`));
        const listener = (request: any) => console.log(`Request finished: ${request.url()}`);
       // page.on('requestfinished', listener);
        await page.goto('/')

        await page.getByRole('link', { name: 'Redirect Link'}).click()
        await page.waitForLoadState()

        
    })  
    
    
   
    test('Disappearing element', async ({ page }) => {
        await page.goto('/')
        await page.getByRole('link', {name: 'Disappearing Elements'}).click()

        await expect(async()=>{
            const ele = await page.locator('ul>li').count()
            await page.reload()
            expect(ele).toBe(5)
            
        }).toPass({timeout: 10000})
        
    })
    

    test('Basic authentication', async ({ page }) => {
        await page.goto('/')
        await page.getByText('Basic Auth').click()
        await expect(page.getByRole('heading', { name: 'Basic Auth'})).toBeVisible()
        
    })
    


    test('Check boxes', async ({ page }) => {
        await page.goto('/')
        await page.getByRole('link', {name : 'Checkboxes'}).click()
        await expect(page).toHaveURL(/checkboxes/)
        const check1 = page.locator('input[type="checkbox"]').first()
        
        await check1.click()
        await expect(check1).toBeChecked()

        await page.locator('input[checked]').all().then(async ele=>{
           await  Promise.all( ele.map(async  e=>{
                await  e.click()
            }))
        })
        await expect(page.locator('#checkboxes').filter({
            hasNot: page.locator('input[type="checkbox"][checked]')
        })).toHaveCount(1)

        
    })

    
    
    
    
})

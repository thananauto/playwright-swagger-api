import { selectors, test, expect } from '@playwright/test'

test.describe.configure({ mode : 'serial'})
test.use({ baseURL : 'https://practicesoftwaretesting.com' })
test.describe('Playwright custom selector', () => {
  
    test('Select previous label', async ({ page }) => {
        const prvsLabelElement =()=>(
            {  
                queryAll(root: Document, selector: string){
                    let all = root.evaluate(`//label[contains(.,'${selector}')]/../preceding-sibling::div//label`, root, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null)
                    return Array.from({ length: all.snapshotLength }, (_, i)=> all.snapshotItem(i))    
                }
    
            }
         )

         const elementBelow = () =>({
            queryAll(root: Document, target: string){

                const [labelIdentifier, fields ] = target.split('|')
                console.log(labelIdentifier)
                //individual element
                const labelUI =root.evaluate(labelIdentifier.trim(), root, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null)
                //elements
                const elements = root.evaluate(fields, root, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null)
                                
                console.log(labelUI.singleNodeValue)
                //get x and y of labelUI
                let  lblEleCoordinates =   (labelUI.singleNodeValue as HTMLElement).getBoundingClientRect()
              
            //get all cordinates of elements
             let  diff = Array.from({ length: elements.snapshotLength }, (_, i)=> elements.snapshotItem(i))
                        .map((e)=>{return { 'xdiff' : Math.abs(lblEleCoordinates.x - (e as any).getBoundingClientRect().x), 'ydiff': Math.abs(lblEleCoordinates.y - (e as any).getBoundingClientRect().y)}} )
               
          
            //get the shortest x-axis
            let xDiff = Array.from(diff).reduce((min: number, eachDiff: any, index: number)=>{
                return eachDiff.xdiff < diff[index].xdiff ? index: min
            },0)
            let yDiff = Array.from(diff).reduce((min: number, eachDiff: any, index: number)=>{
                return eachDiff.ydiff < diff[index].ydiff ? index: min
            },0)

            return Array.from({ length: elements.snapshotLength }, (_, i)=> elements.snapshotItem(i))[yDiff] 
            }

           
            
         })

        await selectors.register('preceding-label', prvsLabelElement)
       // await selectors.register('elementBelow', elementBelow)
        await page.goto('/')
       // await page.getByRole('link',  { name: 'Sign in' }).click()
        const loc = page.locator('preceding-label=Wrench')
     //  const loc = page.locator(`elementBelow=//label[contains(.,'Email address')]|//input`)
        await loc.nth(1).click()
        await expect(loc.nth(1)).toBeChecked()
        
        
    })
    
})

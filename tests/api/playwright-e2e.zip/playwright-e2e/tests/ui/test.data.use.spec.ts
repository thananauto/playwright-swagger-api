import { log } from 'console';
import  {  test, expect } from './../init/data.fixture';


//test.use({ credentials: { apikey: 'testLevelApiKey', secretkey :'testLevelSecretKey' } });
test.describe('Data use test', async() => {

  test('should display data use page', async ({ credentials }) => {
    
    console.log('Credentials:', credentials.apikey, credentials.secretkey);
   
  });

  
})
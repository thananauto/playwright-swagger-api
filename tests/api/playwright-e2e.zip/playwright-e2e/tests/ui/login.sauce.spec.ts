import { test, expect } from '@playwright/test'


test.describe.configure({mode: 'parallel'})

//demoblaze tests
test.describe('Demo blaze tests', async() => {
    test.use({baseURL: 'https://demoblaze.com/index.html', storageState: 'data/.auth/user.json'})

test('Logged In User', async ({ context  }) => {
    
    const page = await context.newPage()
    await page.goto('/')
    await page.locator('#nameofuser').click()
    await page.waitForTimeout(4000)
    await expect(page).toHaveURL(/#/)
    
})

test('SignUP not present', async({ page })=>{

    await page.goto('/')
    await expect(page.getByRole('link', { name: 'Sign up'})).not.toBeVisible()
    await page.waitForTimeout(4000)

})


test('Sign In freshly', async({ page, context })=>{

//await context.clearCookies()
await page.goto('/')
await page.getByRole('link', { name : 'Log in'}).click()

    await page.locator('#loginusername').fill('test')
    await page.locator('#loginpassword').fill('test')
    await page.getByRole('button', { name : 'Log in'}).click()
    await expect(page.getByRole('link', { name: 'Log out'})).toBeVisible()


})


})

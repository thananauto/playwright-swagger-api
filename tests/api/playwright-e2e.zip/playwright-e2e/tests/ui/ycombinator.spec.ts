import { test, expect } from '@playwright/test'

test.describe('Ycombinator test', () => {

    

    test.use({ baseURL:  'https://news.ycombinator.com/newest'})
    test.beforeEach('lauch the website', async ({ page }) => {
        await page.goto('/')
        await expect(page.getByRole('link', { name: 'Hacker News'})).toBeVisible()
    })
    let datesText: string[] =[]
    test('Get the first 100 dates', async ({ page }) => {
              
        while(datesText.length < 100){
        const dates = await page.locator('span.age').all();
       
           //  await Promise.all(dates.map(async e=>{
            dates.forEach(async e =>{
            datesText.push(await e.getAttribute('title') as string)
        })

        await page.getByRole('link', { name: 'More', exact: true}).click();
        await page.waitForLoadState('domcontentloaded')
    }
       // Promise.all(datesText).then(x=>console.log(x))
        console.log(datesText.length)
        
         
        
    })
    


    
})

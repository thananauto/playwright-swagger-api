import { lighthouse as test, expect } from './../init/light.house'
import { playAudit } from 'playwright-lighthouse';
import lighthouse from 'lighthouse'
//import prepareAudit from 'lighthouse/playwright';
//sauce lab tests
test.describe('Check the Login state of UI application', async() => {
    test.use({ baseURL: 'https://www.saucedemo.com'})
    test.describe.configure({mode: 'serial'})
    test.beforeEach(async ({ page }) => {
        await page.goto('https://www.saucedemo.com/');
            await page.locator('[data-test="username"]').fill('standard_user');
            await page.locator('[data-test="password"]').fill('secret_sauce');
            await page.locator('[data-test="login-button"]').click();
           
           
    })

    test('Product details page', { tag: [ '@lighthouse' ]}, async ({ page, port }) => {
       // await page.goto('/')
        await page.waitForTimeout(2000)
        await page.locator('.inventory_item_name ').first().click()
        await expect(page.locator('[data-test="inventory-item-name"]')).toBeVisible();
        await page.locator('[data-test="add-to-cart"]').click();
        await playAudit({
            page,
            port,
            thresholds:{
                performance: 40,
            },
            reports:{
                formats: {
                    html: true,
                },

            }
        });
        await page.locator('[data-test="remove"]').click();
        await page.locator('[data-test="shopping-cart-link"]').click();
        await expect(page.locator('[data-test="inventory-item"]')).not.toBeVisible();

    })

    test('Go to cart page',  {tag: [ '@lighthouse' ]}, async ({ page, port }) => {
       // await page.goto('/')
        await page.waitForTimeout(2000)
        await page.locator('[data-test="shopping-cart-link"]').click();
        const continueBtn = page.locator('[data-test="continue-shopping"]')
        await playAudit({
            page,
            port,
            thresholds:{
                performance: 50,
                accessibility: 50,
               'best-practices': 50,
                seo: 50,
                pwa: 50,
            },
            reports:{
                formats: {
                    html: true,
                },

            }
        });
        const checkout = page.locator('[data-test="checkout"]')
        const btn =  continueBtn.or( checkout).first()
        await expect(btn).toBeVisible()
        
    })
    
    
    
})
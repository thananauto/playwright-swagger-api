import { test, expect, Page } from '@playwright/test'
import { describe } from 'node:test'

test.describe.configure({ mode: 'serial' })
test.use({ baseURL: 'https://www.udacity.com' })
test.describe('Udacity test', async () => {

    interface JsonFormat {
        title: string
        duration: string
        difficultyLevel: string
        numberOfReviews: number
        starsAverage: number
    }

    test('Compare UI with API response', async ({ page, request }) => {

        
        let jsonOP:JsonFormat[] = []
        await page.goto('/catalog', { waitUntil: "domcontentloaded" })
        await page.waitForLoadState('load')
        await expect(page.getByRole('heading', { name: /all programs/i, exact: true })).toBeVisible({ timeout : 10000 })
        await page.getByLabel('Search', { exact : true}).click()
        await page.getByRole('searchbox', { name: 'Search input' }).fill('Testing');
        await page.getByRole('searchbox', { name: 'Search input' }).press('Enter');

        await page.waitForLoadState('domcontentloaded');
        await expect(page.getByRole('heading', { name: 'Search results for' })).toContainText('Testing', { timeout: 10000 })
        await page.getByRole('button', { name: 'Skill', exact: true }).click()
        const searcText = 'Automation testing'
        page.on('response', async response => {
            if (response.url().includes(`/${searcText.replace(" ", "%20")}/`)&& response.request().method().includes('GET')) {
            let json = await response.json()
            //console.log(json.pageProps.catalogSearchResults.searchResultItems)
            let subJson = json['pageProps']['catalogSearchResults']['searchResultItems']

            jsonOP = subJson.map( (ele:any) =>{
                    return {
                        'title' : ele.title,
                        'duration' : ele.duration,
                        'difficultyLevel' : ele.difficultyLevel,
                        'numberOfReviews' : ele.reviewSummary.numberOfReviews,
                        'starsAverage' : ele.reviewSummary.starsAverage,
                    }
            })
            console.log(jsonOP)
            }
            
        })



        await page.getByRole('region', { name: 'Skill' }).getByRole('combobox').fill(searcText);
        await page.getByRole('region', { name: 'Skill' }).getByRole('combobox').press('Enter');
        let text:string = 'Automation testing'
        text = text.charAt(0).toUpperCase() + text.slice(1)
        await expect(page.getByRole('button', { name: searcText })).toBeVisible()

       // await page.waitForTimeout(60000)

        await page.waitForLoadState('load');
      //  await page.waitForSelector('a.chakra-heading')
       // const items = await page.locator('a.chakra-heading').all()
       // expect(items.length).toBeGreaterThanOrEqual(1)

      
       //await page.pause()

       //ui count
       await expect(page.locator('article[role]').first()).toBeVisible({ timeout: 10000})
       const elements = await page.locator('article[role]').all()

       const UI = await Promise.all(elements.map(async ele =>{
           const title = await ele.locator('a.chakra-heading').textContent()
           const metadata = await ele.locator('div.chakra-stack').textContent()
           return {
               'title' : title,
               'metadata' : metadata
           }
       }))
      
   
    expect(jsonOP.length).toEqual(UI.length)

      // Iterate through the UI array and compare with jsonOP
        UI.forEach(uiItem => {
        // Find the corresponding item in jsonOP by title
        const jsonOpItem = jsonOP.find(item => item.title === uiItem.title);

        expect.soft(jsonOpItem?.title).toEqual( uiItem.title)
        if (jsonOpItem) {
        // Build the expected metadata string from jsonOP
        const expectedMetadata = jsonOpItem.numberOfReviews > 0 
            ? `(${jsonOpItem.numberOfReviews})${jsonOpItem.duration}, ${jsonOpItem.difficultyLevel}`
            : `${jsonOpItem.duration}, ${jsonOpItem.difficultyLevel}`;
            expect.soft(uiItem.metadata).toEqual(expectedMetadata)
        // Compare metadata
        }
            
        
        });
            
        
    })


    test('Get UI OP', async({ page })=>{

        await page.goto('/catalog/all/any-price/any-school/Automation%20testing/any-difficulty/any-duration/any-type/relevance/page-1?searchValue=Testing')
       // await page.waitForLoadState('domcontentloaded')

        //await expect()
        await page.waitForLoadState('load');
       
        await expect(page.locator('article[role]').first()).toBeVisible({ timeout: 10000})
        const elements = await page.locator('article[role]').all()

        const op = await Promise.all(elements.map(async ele =>{
            const title = await ele.locator('a.chakra-heading').textContent()
            const metadata = await ele.locator('div.chakra-stack').textContent()
            return {
                'title' : title,
                'metadata' : metadata
            }
        }))
       console.log(op)


    })

    test('compare json', async()=>{
        const jsonOP = [
            {
            title: 'React',
            duration: '2 months',
            difficultyLevel: 'Intermediate',
            numberOfReviews: 559,
            starsAverage: 4.7
          },
          {
            title: 'Full Stack JavaScript Developer',
            duration: '3 months',
            difficultyLevel: 'Intermediate',
            numberOfReviews: 81,
            starsAverage: 4.7
          },
          {
            title: 'React and Redux',
            duration: '1 month',
            difficultyLevel: 'Intermediate',
            numberOfReviews: 0,
            starsAverage: 0
          }]

          const UI = [
            { title: 'React and Redux', metadata: '1 month, Intermediate' },
            {
              title: 'Full Stack JavaScript Developer',
              metadata: '(81)3 months, Intermediate'
            },
            { title: 'React', metadata: '(559)2 months, Intermediate' }
          ]

          expect(jsonOP.length).toEqual(UI.length)

         // Iterate through the UI array and compare with jsonOP
UI.forEach(uiItem => {
    // Find the corresponding item in jsonOP by title
    const jsonOpItem = jsonOP.find(item => item.title === uiItem.title);
  
    expect.soft(jsonOpItem?.title).toEqual( uiItem.title)
    if (jsonOpItem) {
      // Build the expected metadata string from jsonOP
      const expectedMetadata = jsonOpItem.numberOfReviews > 0 
        ? `(${jsonOpItem.numberOfReviews})${jsonOpItem.duration}, ${jsonOpItem.difficultyLevel}`
        : `${jsonOpItem.duration}, ${jsonOpItem.difficultyLevel}`;
        expect.soft(uiItem.metadata).toEqual(expectedMetadata)
      // Compare metadata
    }
        
      
  });
  
    })

   
    
    
})

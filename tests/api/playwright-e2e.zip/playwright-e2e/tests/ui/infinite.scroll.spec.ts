import { test, expect } from '@playwright/test'


test.use({ baseURL: 'https://the-internet.herokuapp.com' })
test.describe('Infinite scroll', () => {
    test('Scroll to bottom', async ({ page }) => {
        await page.goto('/')
        await page.getByRole('link', { name : 'Infinite Scroll' }).click()

        await page.evaluate(async()=>{
            const delay =(ms:number) => new Promise((resolve)=> setTimeout(resolve, ms))
            const height = document.body.scrollHeight
            for(let i=0; i<document.body.scrollHeight; i+=100){
                window.scroll(0,i)
                await delay(100)
            }
        })

        await page.waitForTimeout(3000)

    })
    
})

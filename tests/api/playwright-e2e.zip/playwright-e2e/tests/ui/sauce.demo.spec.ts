// @ts-check
import {test, expect, TestInfo} from '@playwright/test'



test.beforeEach(async ({page}) => {
 //go to home page
 await page.goto('https://www.saucedemo.com/')
 
 
});


///test.afterEach(screenshot)
test('has a page title', async ({ page }, testinfo: TestInfo) => {
    
    await expect(page).toHaveTitle('Swag Labs')
    
    
    
});

test('enter in to application', async ({ page }) => {
    
    await page.getByPlaceholder('username').fill('standard_user');
    await page.getByPlaceholder('password').fill('secret_sauce');
    await page.getByText('Login').click();
    
    //await page.pause()
    //assertion
    const loc = page.locator('.app_logo:has-text("Swag Labs")')
    await expect(loc).toHaveClass('app_logo')
});





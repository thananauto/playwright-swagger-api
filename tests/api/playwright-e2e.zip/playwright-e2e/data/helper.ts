import  { TestInfo, Page } from "@playwright/test";


export  const screenshot = async ( page:Page , testInfo: TestInfo) =>{
    if(testInfo.status != testInfo.expectedStatus){
        console.log(testInfo.status+" "+testInfo.expectedStatus)
        const screenshotPath = testInfo.outputPath('test-result',`failure.png`);
         // Add it to the report.
      testInfo.attachments.push({ name: 'screenshot', path: screenshotPath, contentType: 'image/png' });
      // Take the screenshot itself.
      await page.screenshot({ path: screenshotPath, timeout: 5000 });
    }

}

